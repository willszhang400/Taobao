from flask import Flask, render_template, request, redirect, session, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_login import login_required
from forms import *
import taobao_spider4
import pymysql
import json
import xlrd
import os
pymysql.install_as_MySQLdb()


app = Flask(__name__)
app.config.from_object("config")
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql://root:root@127.0.0.1:3306/taobao"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = True
app.config["SQLALCHEMY_ECHO"] = True
db = SQLAlchemy(app)


@app.route('/')
def index():
    return render_template("index.html")


@app.route('/index2')
def index2():
    return render_template("index2.html")


# 关键字输入
@app.route('/search', methods=["POST", "GET"])
def search():
    keyword = request.form.get("keyword")
    phone = request.form.get("phone")
    pwd = request.form.get("pwd")
    taobao_spider4.main(keyword, phone, pwd)
    # 获取连接对象
    conn = pymysql.connect(
        host="localhost",  # 数据库主机ip地址
        user="root",  # 数据库的登录账号
        password="root",  # 登录密码
        database="taobao",  # 连接的数据库
        port=3306,  # 端口号
        charset="utf8"
    )
    # 获取执行对象
    cur = conn.cursor()
    # 执行sql
    sql = f"select * from {keyword}"
    cur.execute(sql)
    # 获取所有数据
    data = cur.fetchall()
    print(data)
    # 关闭
    cur.close()
    conn.close()
    # return render_template("search.html", data=data)
    data = json.dumps(data, ensure_ascii=False)
    return data


# excel关键字导入
@app.route('/data_list', methods=["POST", "GET"])
def data_list():
    phone = request.form.get("phone")
    pwd = request.form.get("pwd")
    file = request.files['file']
    print(file, file.filename)
    # 文件内容
    f = file.read()
    data = xlrd.open_workbook(file_contents=f)
    table = data.sheets()[0]
    names = data.sheet_names()  # 返回book中所有工作表的名字
    status = data.sheet_loaded(names[0])  # 检查sheet1是否导入完毕
    print(status)
    nrows = table.nrows  # 获取该sheet中的有效行数
    ncols = table.ncols  # 获取该sheet中的有效列数
    print(nrows)
    print(ncols)
    keywords = table.col_values(0)  # 第1列数据
    print(keywords)
    infos = []
    for keyword in keywords:
        taobao_spider4.main(keyword, phone, pwd)
        # 获取连接对象
        conn = pymysql.connect(
            host="localhost",  # 数据库主机ip地址
            user="root",  # 数据库的登录账号
            password="root",  # 登录密码
            database="taobao",  # 连接的数据库
            port=3306,  # 端口号
            charset="utf8"
        )
        # 获取执行对象
        cur = conn.cursor()
        # 执行sql
        sql = f"select * from {keyword}"
        cur.execute(sql)
        # 获取所有数据
        datas = cur.fetchall()
        infos.append(datas)
        # 关闭
        cur.close()
        conn.close()
        # return render_template("search.html", data=data)
    infos = json.dumps(infos, ensure_ascii=False)
    return infos


@app.route("/login", methods=['POST', 'GET'])
@login_required
def login():
    form = LoginForm()
    if form.validate_on_submit():
        if request.method == 'GET':
            return render_template('login.html')
        user = request.form.get('user')
        password = request.form.get('password')
        remember = request.form.get('remember')
        if user == "taobao" and password == "taobao123":
            if remember == '1':
                session.permanent = True
                session["logined"] = user
                return redirect('/home.html')
            else:
                session["logined"] = user
                return redirect('/home.html')
        else:
            return "用户名或密码错误"


# 重设密码
@app.route('/reset', methods=["GET", "POST"])
def reset():
    pass


@app.route("/set/cookie")
def set_cookie():
    """cookie设置"""
    # 创建响应
    response = make_response("set_cookie...")
    # 设置cookie
    response.set_cookie("mycookie1", "laowang", max_age=60 * 10)
    # 返回响应
    return response


@app.route("/get/cookie")
def get_cookie():
    """cookie获取"""
    # 获取cookie
    mycookie1 = request.cookies.get("mycookie1")
    print("mycookie1:", mycookie1)
    return "get_cookie..."


@app.route("/delete/cookie")
def delete_cookie():
    """cookie删除"""
    # 创建响应
    response = make_response("delete_cookie...")
    # 设置cookie
    response.delete_cookie("mycookie1")
    # 返回响应
    return response


@app.route("/set/session")
def set_session():
    """session设置"""
    user = request.form.get('user')
    session["logined"] = user
    return "set session..."


@app.route("/get/session")
def get_session():
    """session获取"""
    print(session.get("logined"))
    return "get session..."


@app.route("/delete/session")
def delete_session():
    """session删除"""
    # 删除
    session.pop("logined")
    # del session["logined"]
    # 清空
    # session.clear()
    return "delete session..."


if __name__ == '__main__':
    app.run(host="172.16.3.109", port=5000, debug=True)
