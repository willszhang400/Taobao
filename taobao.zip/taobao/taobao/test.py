keywords = ['水果', '华为', '鲜花']
for keyword in keywords:
    print(keyword)
