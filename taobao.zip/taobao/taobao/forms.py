from flask_wtf import FlaskForm
from wtforms import StringField, BooleanField, PasswordField, SubmitField
from wtforms.validators import DataRequired


# 定义的表单都需要继承FlaskForm
class LoginForm(FlaskForm):
    user = StringField('User', validators=[DataRequired()])
    passport = PasswordField('Password', validators=[DataRequired()])
    remember = BooleanField('remember', default=False)

class ChangePasswordForm(FlaskForm):
    old_password = PasswordField('OLD Password', validators=[DataRequired()])
    password = PasswordField('New password', validators=[DataRequired()], message='Passwords must match')
    password2 = PasswordField('Confirm new password', validators=[DataRequired()])
    submit = SubmitField('Update Password')