import os
import time
from selenium import webdriver
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
import xlsxwriter
import pymysql


def save_to_db(data, keyword):
    """
    写入mysql数据库
    """
    # 连接mysql
    conn = pymysql.connect(
        host="localhost",
        user="root",
        password="root",
        port=3306,
    )
    # 创建游标
    cur = conn.cursor()
    # 创建数据库taobao
    cur.execute("""create database if not exists taobao""")
    conn.select_db("taobao")
    # 创建表
    cur.execute(f"""drop table if exists {keyword}""")  # 如果存在删除
    cur.execute(f"""create table {keyword}(id int auto_increment primary key,sales varchar(100))""")
    for i in data:
        sql = f"""insert into {keyword}(id,sales) values(null,'{i["销货量"]}')"""
        # 写入数据
        cur.execute(sql)
        # 提交
        conn.commit()
    # 关闭
    cur.close()
    conn.close()
    print("数据已存入数据库")


def write_to_file(data, keyword):
    """
    保存数据
    """
    file_name = f"./{keyword}.xlsx"
    if not os.path.exists(file_name):
        # 创建工作薄
        workbook = xlsxwriter.Workbook(f"./{keyword}.xlsx")
        worksheet = workbook.add_worksheet()
        worksheet.set_column(1, 1, 15)
        worksheet.write('A1', "销货量")
        row = 1
        col = 0
        for i in data:
            worksheet.write_string(row, col, str(i["销货量"]))
            row += 1
        workbook.close()
    else:
        print("请删除已有的excel，重新输入获取最新消息")


def parse_data(page, wait, infos, driver):
    """
    解析数据
    """
    for j in range(1, page + 1):
        print("正在爬取第", j, "页")
        time.sleep(2)
        if j < page + 1:
            # 销货量提取
            sell_nums = wait.until(EC.presence_of_all_elements_located((By.XPATH, '//div[@class="deal-cnt"]')))
            nums = []
            for sell_num in sell_nums:
                # print(sell_num.text)
                nums.append(sell_num.text)
            # 销货量存储
            for i in range(len(nums)):
                item = {}
                item["销货量"] = nums[i]
                # print(item)
                infos.append(item)
            # 点击下一页
            driver.find_element_by_xpath('//li[@class="item next"]/a/span[1]').click()
    print(infos)
    print(len(infos))
    return infos


def main(keyword, phone, pwd):
    infos = []
    max_page = 3
    base_url = "https://s.taobao.com/search?q="
    # 1.封装浏览器标识
    dcap = dict(DesiredCapabilities.CHROME)
    dcap[
        "chrome.page.settings.userAgent"] = 'user-agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'

    option = webdriver.ChromeOptions()
    option.add_argument('--headless')
    option.add_argument('--disable-gpu')
    # 2.创建驱动
    # driver = webdriver.Chrome(desired_capabilities=dcap)
    # 2.无头驱动
    # driver = webdriver.PhantomJS()
    driver = webdriver.Chrome(desired_capabilities=dcap, chrome_options=option)
    # 3.更改内核
    script = """Object.defineProperties(navigator, {webdriver:{get:()=>undefined}})"""
    driver.execute_script(script)
    # 4.最大等待时长
    wait = WebDriverWait(driver, 30)
    driver.get(base_url)
    # 5.账号密码登录
    driver.find_element_by_xpath('//div[@class="input-plain-wrap input-wrap-loginid "]/input').send_keys(phone)
    driver.find_element_by_xpath('//div[@class="input-plain-wrap input-wrap-password"]/input').send_keys(pwd)
    driver.find_element_by_xpath('//div[@class="fm-btn"]/button').click()
    time.sleep(10)
    # # 5.手机淘宝扫码登陆
    # print('请在10秒内完成手机淘宝扫码验证')
    # driver.find_element_by_xpath('//div[@id="login"]/div/i').click()
    # time.sleep(10)
    # # 5.支付宝扫码登陆
    # driver.find_element_by_xpath('//div[@class="login-blocks sns-login-links"]/a[2]').click()
    # 6.填充关键字
    driver.find_element_by_css_selector('#q').send_keys(keyword)
    # 7.点击搜索
    driver.find_element_by_xpath('//div[@class="search"]/form/button').click()
    # 8.点击按销量从高到低排序
    driver.find_element_by_xpath('//ul[@class="sorts"]/li[2]/a').click()
    # 9.解析数据
    data = parse_data(max_page, wait, infos, driver)
    # 10.保存excel
    write_to_file(data, keyword)
    # 11.缓存到数据库
    save_to_db(data, keyword)
    # 12.退出
    driver.quit()
